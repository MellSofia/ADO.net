﻿using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
using System.Reflection.PortableExecutable;
namespace DZ_on_24._12._24
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"Server=.\SQLEXPRESS;database=VegetablesANDFruits;Integrated Security=true;TrustServerCertificate=true";
            SqlConnection conn = null;
            conn = new SqlConnection(connectionString);
            SqlDataReader reader = null;

            int num = -1;

            String[] str = { "Отображение всей таблицы", "Калорийность ниже средней", 
                "Калорийность выше средней", "Калорийность между min и max", 
                "Жёлтые или красные", "Количество овощей и фруктов каждого цвета", 
                "Овощи и фрукты", "Цвет", "Максимальная калорийность", "Минимальная калорийность",
                "Средняя калорийность", "Количество овощей", "Количество фруктов",
                "Количество овощей и фруктов красного цвета"};

            try { // открытие соединения
                conn.Open();
                
                SqlCommand sqlCommand = new SqlCommand("SELECT * FROM VegetablesANDFruits;" + "SELECT Name FROM VegetablesANDFruits;" + 
                    "SELECT Color FROM VegetablesANDFruits;" + "SELECT MAX(Calories) FROM VegetablesANDFruits" + "SELECT MIN(Calories) FROM VegetablesANDFruits", conn);
                
                reader = sqlCommand.ExecuteReader();
                Console.WriteLine(reader.GetName(0) + " " + " " + reader.GetName(1) + " " + reader.GetName(2) + " " + reader.GetName(3));

                int line = 0;
                while (reader.Read())
                {
                    if (line == 0) 
                    {
                        Console.Write("  ");
                        for (int i = 0; i < reader.FieldCount; i++)
                            Console.Write(reader.GetName(i).ToString() + "\t"); 
                        Console.WriteLine();
                    }
                    line++;
                    Console.Write("  ");
                    Console.WriteLine(reader[0] + "\t" + reader[1] + "\t" + reader[2] + "\t" + reader[3]);
                }
            }
            catch (Exception ex) {
                Console.WriteLine("  Ошибка: " + ex.Message);
            }
            finally {
              
            }
        }
    }
}
